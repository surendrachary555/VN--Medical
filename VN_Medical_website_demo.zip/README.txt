VN Medical — Free Website Demo

Open index.html in a browser to test the medicine search.

The prototype uses the uploaded sample Excel inventory embedded in the page.
For a production version, the inventory should be moved to a proper database/backend
so the shop owner can update stock and customers see the latest availability.

The Request / Contact Shop button is currently a demo mail action and should be
connected to the shop's actual phone, WhatsApp, or email details once provided.
